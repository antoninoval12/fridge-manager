"""Context processor: rende disponibile in ogni template il numero di
notifiche non lette dell'utente autenticato."""

from .models import Notifica


def notifiche_non_lette(request):
    if request.user.is_authenticated:
        count = Notifica.objects.filter(utente=request.user, letta=False).count()
    else:
        count = 0
    return {"notifiche_non_lette": count}
