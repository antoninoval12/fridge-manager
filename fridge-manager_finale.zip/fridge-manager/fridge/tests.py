"""Test essenziali per il Fridge Manager."""

from datetime import timedelta

from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .models import (
    Categoria,
    Condivisione,
    FridgeItem,
    Frigorifero,
    IngredienteRicetta,
    Prodotto,
    Ricetta,
)


class ModelliTest(TestCase):
    def setUp(self):
        self.mario = User.objects.create_user("mario", password="Password123!")
        self.giulia = User.objects.create_user("giulia", password="Password123!")
        self.cat = Categoria.objects.create(nome="Latticini")
        self.latte = Prodotto.objects.create(nome="Latte", categoria=self.cat)
        self.frigo = Frigorifero.objects.create(nome="Frigo test")
        Condivisione.objects.create(
            utente=self.mario, frigorifero=self.frigo, ruolo=Condivisione.Ruolo.OWNER
        )

    def test_proprietario_e_ruolo(self):
        self.assertEqual(self.frigo.proprietario, self.mario)
        self.assertTrue(self.frigo.is_owner(self.mario))
        self.assertIsNone(self.frigo.ruolo_di(self.giulia))

    def test_in_scadenza_e_scaduto(self):
        item = FridgeItem.objects.create(
            frigorifero=self.frigo,
            prodotto=self.latte,
            quantita=1,
            data_scadenza=timezone.localdate() + timedelta(days=1),
        )
        self.assertTrue(item.in_scadenza)
        item.data_scadenza = timezone.localdate() - timedelta(days=1)
        self.assertTrue(item.is_scaduto)


class VisteTest(TestCase):
    def setUp(self):
        self.mario = User.objects.create_user("mario", password="Password123!")
        self.estraneo = User.objects.create_user("estraneo", password="Password123!")
        self.frigo = Frigorifero.objects.create(nome="Frigo privato")
        Condivisione.objects.create(
            utente=self.mario, frigorifero=self.frigo, ruolo=Condivisione.Ruolo.OWNER
        )

    def test_home_richiede_login(self):
        resp = self.client.get(reverse("home"))
        self.assertEqual(resp.status_code, 302)  # redirect al login

    def test_accesso_frigo_di_altri_vietato(self):
        self.client.login(username="estraneo", password="Password123!")
        resp = self.client.get(reverse("frigorifero_detail", args=[self.frigo.pk]))
        self.assertEqual(resp.status_code, 403)

    def test_membro_vede_proprio_frigo(self):
        self.client.login(username="mario", password="Password123!")
        resp = self.client.get(reverse("frigorifero_detail", args=[self.frigo.pk]))
        self.assertEqual(resp.status_code, 200)


class RicetteSuggeriteTest(TestCase):
    def setUp(self):
        self.mario = User.objects.create_user("mario", password="Password123!")
        self.frigo = Frigorifero.objects.create(nome="Frigo")
        Condivisione.objects.create(
            utente=self.mario, frigorifero=self.frigo, ruolo=Condivisione.Ruolo.OWNER
        )
        cat = Categoria.objects.create(nome="Latticini")
        self.uova = Prodotto.objects.create(nome="Uova", categoria=cat)
        self.ricetta = Ricetta.objects.create(nome="Uova sode", istruzioni="Bolli le uova.")
        IngredienteRicetta.objects.create(
            ricetta=self.ricetta, prodotto=self.uova, quantita_necessaria=2
        )

    def test_ricetta_realizzabile_con_ingredienti(self):
        FridgeItem.objects.create(
            frigorifero=self.frigo,
            prodotto=self.uova,
            quantita=6,
            data_scadenza=timezone.localdate() + timedelta(days=10),
        )
        self.client.login(username="mario", password="Password123!")
        resp = self.client.get(reverse("ricette_suggerite", args=[self.frigo.pk]))
        self.assertEqual(resp.status_code, 200)
        self.assertIn(self.ricetta, resp.context["realizzabili"])
