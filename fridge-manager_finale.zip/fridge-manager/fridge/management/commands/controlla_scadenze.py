"""
Comando: python manage.py controlla_scadenze

Scorre gli elementi disponibili di tutti i frigoriferi, marca come "scaduto"
quelli oltre la data di scadenza e genera una notifica (per ciascun membro del
frigorifero) per i prodotti scaduti o in scadenza entro pochi giorni.
Evita di creare notifiche duplicate.
"""

from django.core.management.base import BaseCommand

from fridge.models import Condivisione, FridgeItem, Notifica


class Command(BaseCommand):
    help = "Aggiorna lo stato degli elementi scaduti e genera le notifiche."

    def handle(self, *args, **options):
        scaduti = 0
        notifiche_create = 0

        disponibili = FridgeItem.objects.filter(
            stato=FridgeItem.Stato.DISPONIBILE
        ).select_related("prodotto", "frigorifero")

        for item in disponibili:
            avvisa = False
            if item.is_scaduto:
                item.stato = FridgeItem.Stato.SCADUTO
                item.save(update_fields=["stato"])
                scaduti += 1
                messaggio = f"'{item.prodotto}' nel frigo '{item.frigorifero}' e' scaduto."
                avvisa = True
            elif item.in_scadenza:
                giorni = item.giorni_alla_scadenza
                quando = "oggi" if giorni == 0 else f"tra {giorni} giorni"
                messaggio = (
                    f"'{item.prodotto}' nel frigo '{item.frigorifero}' scade {quando}."
                )
                avvisa = True

            if not avvisa:
                continue

            membri = Condivisione.objects.filter(
                frigorifero=item.frigorifero
            ).values_list("utente_id", flat=True)

            for utente_id in membri:
                # Evita duplicati: stessa notifica non ancora letta per lo stesso item
                gia_presente = Notifica.objects.filter(
                    utente_id=utente_id,
                    fridge_item=item,
                    messaggio=messaggio,
                ).exists()
                if not gia_presente:
                    Notifica.objects.create(
                        utente_id=utente_id,
                        fridge_item=item,
                        messaggio=messaggio,
                    )
                    notifiche_create += 1

        self.stdout.write(
            self.style.SUCCESS(
                f"Completato: {scaduti} elementi segnati come scaduti, "
                f"{notifiche_create} notifiche create."
            )
        )
