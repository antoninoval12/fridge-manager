"""
Comando: python manage.py popola_db [--reset]

Popola il database con un set di dati ricco e realistico, pensato per poter
avviare l'app e mostrarla subito (demo "chiavi in mano"):
- categorie ed emoji
- ~30 prodotti di catalogo
- ricette con ingredienti
- piu' utenti
- frigoriferi condivisi con ruoli diversi
- elementi con scadenze realistiche (alcuni scaduti, alcuni in scadenza, molti ok)
- notifiche generate automaticamente

Con --reset svuota prima i dati applicativi (mantiene il superuser admin).

Utenti creati (password: Password123!):
  - admin   -> superuser
  - mario   -> proprietario "Frigo di casa"
  - giulia  -> membro di casa + proprietaria "Frigo ufficio"
  - luca    -> proprietario "Casa al mare"
"""

from datetime import timedelta

from django.contrib.auth.models import User
from django.core.management.base import BaseCommand
from django.utils import timezone

from fridge.models import (
    Categoria,
    Condivisione,
    FridgeItem,
    Frigorifero,
    IngredienteRicetta,
    Notifica,
    Prodotto,
    Ricetta,
)

PASSWORD = "Password123!"

CATEGORIE = ["Bevande", "Verdura", "Frutta", "Carne", "Pesce",
             "Latticini", "Dispensa", "Surgelati", "Dolci"]

# prodotto -> categoria
PRODOTTI = {
    "Latte": "Latticini", "Uova": "Latticini", "Burro": "Latticini",
    "Parmigiano": "Latticini", "Mozzarella": "Latticini", "Yogurt": "Latticini",
    "Pomodori": "Verdura", "Zucchine": "Verdura", "Insalata": "Verdura",
    "Cipolla": "Verdura", "Carote": "Verdura", "Spinaci": "Verdura",
    "Mele": "Frutta", "Banane": "Frutta", "Limoni": "Frutta", "Fragole": "Frutta",
    "Petto di pollo": "Carne", "Macinato di manzo": "Carne", "Prosciutto": "Carne",
    "Salmone": "Pesce", "Gamberi": "Pesce",
    "Acqua": "Bevande", "Succo d'arancia": "Bevande", "Birra": "Bevande", "Vino bianco": "Bevande",
    "Pasta": "Dispensa", "Riso": "Dispensa", "Farina": "Dispensa", "Olio d'oliva": "Dispensa", "Passata di pomodoro": "Dispensa",
    "Piselli surgelati": "Surgelati", "Gelato": "Surgelati",
    "Cioccolato": "Dolci", "Biscotti": "Dolci",
}

RICETTE = {
    "Pasta al pomodoro": {
        "istruzioni": "Cuoci la pasta in acqua salata. Soffriggi la cipolla, aggiungi la "
        "passata e cuoci 10 minuti. Condisci la pasta e completa con parmigiano.",
        "ingredienti": [("Pasta", 1), ("Passata di pomodoro", 1), ("Cipolla", 1), ("Olio d'oliva", 1), ("Parmigiano", 1)],
    },
    "Frittata di zucchine": {
        "istruzioni": "Sbatti le uova con un pizzico di sale. Aggiungi le zucchine a rondelle "
        "e cuoci in padella con un filo d'olio fino a doratura.",
        "ingredienti": [("Uova", 4), ("Zucchine", 2), ("Olio d'oliva", 1)],
    },
    "Pollo al limone": {
        "istruzioni": "Rosola il petto di pollo, sfuma con succo di limone e completa con "
        "una noce di burro per una salsa cremosa.",
        "ingredienti": [("Petto di pollo", 1), ("Limoni", 2), ("Burro", 1)],
    },
    "Torta di mele": {
        "istruzioni": "Mescola farina, uova e burro. Unisci le mele a fette e inforna a 180°C "
        "per 40 minuti.",
        "ingredienti": [("Farina", 1), ("Uova", 3), ("Burro", 1), ("Mele", 3)],
    },
    "Risotto ai gamberi": {
        "istruzioni": "Tosta il riso, aggiungi brodo poco alla volta. A meta' cottura unisci "
        "i gamberi. Manteca con burro fuori dal fuoco.",
        "ingredienti": [("Riso", 1), ("Gamberi", 1), ("Cipolla", 1), ("Burro", 1)],
    },
    "Insalata fresca": {
        "istruzioni": "Lava l'insalata, aggiungi pomodori a spicchi e carote a julienne. "
        "Condisci con olio e sale.",
        "ingredienti": [("Insalata", 1), ("Pomodori", 2), ("Carote", 1), ("Olio d'oliva", 1)],
    },
}

# Frigoriferi: nome -> [(username_owner_o_member, ruolo)], elementi: [(prodotto, qta, giorni_da_oggi)]
FRIGORIFERI = {
    "Frigo di casa": {
        "membri": [("mario", "owner"), ("giulia", "member")],
        "elementi": [
            ("Latte", 2, 2), ("Uova", 6, 9), ("Burro", 1, 25), ("Parmigiano", 1, 60),
            ("Yogurt", 4, 1), ("Pomodori", 5, 3), ("Zucchine", 3, 5), ("Insalata", 1, -1),
            ("Cipolla", 4, 30), ("Carote", 6, 14), ("Mele", 5, 12), ("Banane", 4, 2),
            ("Petto di pollo", 2, 1), ("Macinato di manzo", 1, -2), ("Pasta", 3, 320),
            ("Passata di pomodoro", 2, 200), ("Olio d'oliva", 1, 250), ("Birra", 6, 90),
        ],
    },
    "Frigo ufficio": {
        "membri": [("giulia", "owner"), ("mario", "member"), ("luca", "member")],
        "elementi": [
            ("Acqua", 12, 180), ("Succo d'arancia", 3, 3), ("Yogurt", 6, 4),
            ("Mele", 8, 7), ("Biscotti", 2, 120), ("Cioccolato", 1, 200),
        ],
    },
    "Casa al mare": {
        "membri": [("luca", "owner")],
        "elementi": [
            ("Vino bianco", 4, 400), ("Pasta", 2, 300), ("Passata di pomodoro", 3, 220),
            ("Gelato", 2, 60), ("Birra", 12, 80), ("Limoni", 6, 10),
        ],
    },
}


class Command(BaseCommand):
    help = "Popola il database con dati di esempio ricchi e realistici."

    def add_arguments(self, parser):
        parser.add_argument(
            "--reset", action="store_true",
            help="Svuota i dati applicativi prima di ripopolare.",
        )

    def handle(self, *args, **options):
        if options["reset"]:
            self.stdout.write("Reset dei dati in corso...")
            Notifica.objects.all().delete()
            FridgeItem.objects.all().delete()
            IngredienteRicetta.objects.all().delete()
            Ricetta.objects.all().delete()
            Condivisione.objects.all().delete()
            Frigorifero.objects.all().delete()
            Prodotto.objects.all().delete()
            Categoria.objects.all().delete()
            User.objects.filter(is_superuser=False).delete()

        oggi = timezone.localdate()

        # Categorie
        cat = {n: Categoria.objects.get_or_create(nome=n)[0] for n in CATEGORIE}

        # Prodotti
        prod = {}
        for nome, categoria in PRODOTTI.items():
            prod[nome] = Prodotto.objects.get_or_create(
                nome=nome, defaults={"categoria": cat[categoria]}
            )[0]

        # Ricette
        for nome, dati in RICETTE.items():
            ricetta, creata = Ricetta.objects.get_or_create(
                nome=nome, defaults={"istruzioni": dati["istruzioni"]}
            )
            if creata:
                for p_nome, qta in dati["ingredienti"]:
                    IngredienteRicetta.objects.create(
                        ricetta=ricetta, prodotto=prod[p_nome], quantita_necessaria=qta
                    )

        # Utenti
        utenti = {
            "admin": self._utente("admin", "admin@example.com", superuser=True),
            "mario": self._utente("mario", "mario@example.com"),
            "giulia": self._utente("giulia", "giulia@example.com"),
            "luca": self._utente("luca", "luca@example.com"),
        }

        # Frigoriferi + condivisioni + elementi
        n_elementi = 0
        for nome, dati in FRIGORIFERI.items():
            frigo, creato = Frigorifero.objects.get_or_create(nome=nome)
            if not creato:
                continue
            for username, ruolo in dati["membri"]:
                Condivisione.objects.create(
                    utente=utenti[username], frigorifero=frigo,
                    ruolo=Condivisione.Ruolo.OWNER if ruolo == "owner" else Condivisione.Ruolo.MEMBER,
                )
            for p_nome, qta, giorni in dati["elementi"]:
                stato = (FridgeItem.Stato.SCADUTO if giorni < 0
                         else FridgeItem.Stato.DISPONIBILE)
                FridgeItem.objects.create(
                    frigorifero=frigo, prodotto=prod[p_nome], quantita=qta,
                    data_scadenza=oggi + timedelta(days=giorni), stato=stato,
                )
                n_elementi += 1

        # Genera le notifiche (riusa la stessa logica del comando dedicato)
        from django.core.management import call_command
        call_command("controlla_scadenze")

        self.stdout.write(self.style.SUCCESS(
            f"Database popolato: {len(utenti)} utenti, {Frigorifero.objects.count()} frigoriferi, "
            f"{n_elementi} elementi, {Ricetta.objects.count()} ricette."
        ))
        self.stdout.write("Login demo:  mario / giulia / luca / admin   —  password: " + PASSWORD)

    def _utente(self, username, email, superuser=False):
        u = User.objects.filter(username=username).first()
        if u:
            return u
        if superuser:
            return User.objects.create_superuser(username, email, PASSWORD)
        return User.objects.create_user(username, email, PASSWORD)
