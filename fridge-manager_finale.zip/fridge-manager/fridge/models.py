"""
Modelli del Fridge Manager.

Traduzione dello schema relazionale descritto nella documentazione:
- la gerarchia Utente -> Owner/Member non genera tabelle separate ma viene
  riassorbita nell'attributo `ruolo` della relazione associativa Condivisione
  (sostituzione della gerarchia con una relazione);
- l'entita' Utente coincide con il modello User integrato di Django.
"""

from django.conf import settings
from django.core.validators import MinValueValidator
from django.db import models
from django.utils import timezone

# Numero di giorni entro cui un prodotto e' considerato "in scadenza".
GIORNI_SCADENZA = 3


class Categoria(models.Model):
    """Classificazione tematica dei prodotti (es. Bevande, Verdura)."""

    nome = models.CharField(max_length=100, unique=True)

    class Meta:
        verbose_name = "Categoria"
        verbose_name_plural = "Categorie"
        ordering = ["nome"]

    def __str__(self):
        return self.nome

    # Emoji rappresentativa per il "frigo visuale" (solo logica Python, nessuna libreria)
    EMOJI = {
        "bevande": "\U0001F964",      # bicchiere con cannuccia
        "verdura": "\U0001F955",      # carota
        "frutta": "\U0001F34E",       # mela
        "carne": "\U0001F356",        # carne
        "latticini": "\U0001F9C0",    # formaggio
        "dispensa": "\U0001F35D",     # spaghetti
        "pesce": "\U0001F41F",        # pesce
        "surgelati": "\U0001F9CA",    # cubetto di ghiaccio
        "dolci": "\U0001F370",        # torta
    }

    @property
    def emoji(self):
        return self.EMOJI.get(self.nome.strip().lower(), "\U0001F37D")  # piatto+posate


class Prodotto(models.Model):
    """Anagrafica di un alimento, indipendente dal frigorifero."""

    nome = models.CharField(max_length=150)
    categoria = models.ForeignKey(
        Categoria, on_delete=models.PROTECT, related_name="prodotti"
    )

    class Meta:
        verbose_name = "Prodotto"
        verbose_name_plural = "Prodotti"
        ordering = ["nome"]

    def __str__(self):
        return self.nome


class Frigorifero(models.Model):
    """Contenitore logico creato da un utente e condivisibile con altri."""

    nome = models.CharField(max_length=120)
    data_creazione = models.DateTimeField(auto_now_add=True)
    membri = models.ManyToManyField(
        settings.AUTH_USER_MODEL,
        through="Condivisione",
        related_name="frigoriferi",
    )

    class Meta:
        verbose_name = "Frigorifero"
        verbose_name_plural = "Frigoriferi"
        ordering = ["nome"]

    def __str__(self):
        return self.nome

    @property
    def proprietario(self):
        """Restituisce l'utente con ruolo owner (vincolo: uno solo per frigo)."""
        cond = self.condivisioni.filter(ruolo=Condivisione.Ruolo.OWNER).first()
        return cond.utente if cond else None

    def ruolo_di(self, utente):
        """Ruolo dell'utente sul frigorifero, oppure None se non e' membro."""
        cond = self.condivisioni.filter(utente=utente).first()
        return cond.ruolo if cond else None

    def is_owner(self, utente):
        return self.ruolo_di(utente) == Condivisione.Ruolo.OWNER


class Condivisione(models.Model):
    """
    Relazione associativa tra Utente e Frigorifero.

    Realizza, tramite l'attributo `ruolo`, la specializzazione parziale e
    sovrapposta Owner/Member discussa nella documentazione.
    """

    class Ruolo(models.TextChoices):
        OWNER = "owner", "Proprietario"
        MEMBER = "member", "Membro"

    utente = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="condivisioni"
    )
    frigorifero = models.ForeignKey(
        Frigorifero, on_delete=models.CASCADE, related_name="condivisioni"
    )
    ruolo = models.CharField(
        max_length=10, choices=Ruolo.choices, default=Ruolo.MEMBER
    )
    data_aggiunta = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Condivisione"
        verbose_name_plural = "Condivisioni"
        constraints = [
            # Un utente non puo' essere associato due volte allo stesso frigorifero
            models.UniqueConstraint(
                fields=["utente", "frigorifero"], name="unique_utente_frigorifero"
            )
        ]

    def __str__(self):
        return f"{self.utente} - {self.frigorifero} ({self.get_ruolo_display()})"


class FridgeItem(models.Model):
    """Presenza concreta di un prodotto in uno specifico frigorifero."""

    class Stato(models.TextChoices):
        DISPONIBILE = "disponibile", "Disponibile"
        CONSUMATO = "consumato", "Consumato"
        SCADUTO = "scaduto", "Scaduto"

    frigorifero = models.ForeignKey(
        Frigorifero, on_delete=models.CASCADE, related_name="elementi"
    )
    prodotto = models.ForeignKey(
        Prodotto, on_delete=models.PROTECT, related_name="elementi"
    )
    quantita = models.PositiveIntegerField(
        default=1, validators=[MinValueValidator(1)]
    )
    data_scadenza = models.DateField()
    data_inserimento = models.DateTimeField(auto_now_add=True)
    stato = models.CharField(
        max_length=12, choices=Stato.choices, default=Stato.DISPONIBILE
    )

    class Meta:
        verbose_name = "Elemento del frigorifero"
        verbose_name_plural = "Elementi del frigorifero"
        ordering = ["data_scadenza"]

    def __str__(self):
        return f"{self.prodotto} x{self.quantita}"

    @property
    def giorni_alla_scadenza(self):
        return (self.data_scadenza - timezone.localdate()).days

    @property
    def is_scaduto(self):
        return self.data_scadenza < timezone.localdate()

    @property
    def in_scadenza(self):
        """True se scade entro GIORNI_SCADENZA giorni (e non e' gia' scaduto)."""
        return 0 <= self.giorni_alla_scadenza <= GIORNI_SCADENZA


class Ricetta(models.Model):
    """Preparazione culinaria con istruzioni e ingredienti."""

    nome = models.CharField(max_length=150)
    istruzioni = models.TextField()
    ingredienti = models.ManyToManyField(
        Prodotto, through="IngredienteRicetta", related_name="ricette"
    )

    class Meta:
        verbose_name = "Ricetta"
        verbose_name_plural = "Ricette"
        ordering = ["nome"]

    def __str__(self):
        return self.nome


class IngredienteRicetta(models.Model):
    """Associazione tra una ricetta e un prodotto, con la quantita' necessaria."""

    ricetta = models.ForeignKey(
        Ricetta, on_delete=models.CASCADE, related_name="lista_ingredienti"
    )
    prodotto = models.ForeignKey(
        Prodotto, on_delete=models.PROTECT, related_name="usato_in"
    )
    quantita_necessaria = models.PositiveIntegerField(
        default=1, validators=[MinValueValidator(1)]
    )

    class Meta:
        verbose_name = "Ingrediente"
        verbose_name_plural = "Ingredienti"
        constraints = [
            models.UniqueConstraint(
                fields=["ricetta", "prodotto"], name="unique_ricetta_prodotto"
            )
        ]

    def __str__(self):
        return f"{self.prodotto} ({self.quantita_necessaria})"


class Notifica(models.Model):
    """Avviso generato dal sistema e destinato a un utente."""

    utente = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notifiche"
    )
    fridge_item = models.ForeignKey(
        FridgeItem,
        on_delete=models.CASCADE,
        related_name="notifiche",
        null=True,
        blank=True,
    )
    messaggio = models.CharField(max_length=255)
    data_creazione = models.DateTimeField(auto_now_add=True)
    letta = models.BooleanField(default=False)

    class Meta:
        verbose_name = "Notifica"
        verbose_name_plural = "Notifiche"
        ordering = ["-data_creazione"]

    def __str__(self):
        return self.messaggio
