"""
Viste del Fridge Manager.

Tutte le interrogazioni al database usano esclusivamente il Django ORM
(query parametrizzate): questo neutralizza per costruzione gli attacchi di
tipo SQL injection. La vista di login implementa inoltre un semplice
meccanismo di throttling come contromisura agli attacchi brute-force.
"""

from collections import defaultdict

from django.contrib import messages
from django.contrib.auth import authenticate
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.core.cache import cache
from django.db.models import Sum
from django.http import HttpResponseForbidden
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from .forms import (
    CondivisioneForm,
    FridgeItemForm,
    FridgeItemUpdateForm,
    FrigoriferoForm,
    ProdottoForm,
    RegistrazioneForm,
)
from .models import (
    Categoria,
    Condivisione,
    FridgeItem,
    Frigorifero,
    Notifica,
    Prodotto,
    Ricetta,
)

# --- Parametri throttling login (contromisura brute-force) ---
MAX_TENTATIVI = 5
BLOCCO_SECONDI = 300  # 5 minuti


# =====================================================================
#  AUTENTICAZIONE
# =====================================================================
def _chiave_throttle(request, username):
    ip = request.META.get("REMOTE_ADDR", "sconosciuto")
    return f"login-fail:{ip}:{username}"


def login_view(request):
    if request.user.is_authenticated:
        return redirect("home")

    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "")
        chiave = _chiave_throttle(request, username)
        tentativi = cache.get(chiave, 0)

        if tentativi >= MAX_TENTATIVI:
            messages.error(
                request,
                "Troppi tentativi di accesso falliti. Riprova tra qualche minuto.",
            )
            return render(request, "registration/login.html")

        utente = authenticate(request, username=username, password=password)
        if utente is not None:
            auth_login(request, utente)
            cache.delete(chiave)
            return redirect(request.GET.get("next") or "home")

        cache.set(chiave, tentativi + 1, BLOCCO_SECONDI)
        messages.error(request, "Credenziali non valide.")

    return render(request, "registration/login.html")


@require_POST
def logout_view(request):
    auth_logout(request)
    return redirect("login")


def register_view(request):
    if request.user.is_authenticated:
        return redirect("home")
    if request.method == "POST":
        form = RegistrazioneForm(request.POST)
        if form.is_valid():
            utente = form.save()
            auth_login(request, utente)
            messages.success(request, "Registrazione completata. Benvenuto!")
            return redirect("home")
    else:
        form = RegistrazioneForm()
    return render(request, "registration/register.html", {"form": form})


# =====================================================================
#  HELPER DI AUTORIZZAZIONE
# =====================================================================
def _frigo_per_membro(request, pk):
    """Restituisce il frigorifero solo se l'utente ne e' membro, altrimenti 403."""
    frigo = get_object_or_404(Frigorifero, pk=pk)
    if frigo.ruolo_di(request.user) is None:
        return None
    return frigo


# =====================================================================
#  FRIGORIFERI
# =====================================================================
@login_required
def home(request):
    condivisioni = (
        Condivisione.objects.filter(utente=request.user)
        .select_related("frigorifero")
        .order_by("frigorifero__nome")
    )
    frigo_ids = [c.frigorifero_id for c in condivisioni]

    # Tutti gli elementi NON consumati dei frigoriferi dell'utente.
    # Includiamo sia quelli ancora "disponibili" sia quelli gia' marcati "scaduto",
    # cosi' il conteggio degli scaduti e' sempre corretto.
    elementi = (
        FridgeItem.objects.filter(frigorifero_id__in=frigo_ids)
        .exclude(stato=FridgeItem.Stato.CONSUMATO)
        .select_related("prodotto", "prodotto__categoria", "frigorifero")
        .order_by("data_scadenza")
    )

    in_scadenza, scaduti = [], []
    n_disponibili = 0
    conteggi = {fid: 0 for fid in frigo_ids}
    for item in elementi:
        conteggi[item.frigorifero_id] = conteggi.get(item.frigorifero_id, 0) + 1
        # Scaduto = stato esplicito "scaduto" OPPURE data di scadenza gia' passata
        if item.stato == FridgeItem.Stato.SCADUTO or item.is_scaduto:
            scaduti.append(item)
        else:
            n_disponibili += 1
            if item.in_scadenza:
                in_scadenza.append(item)

    # Statistiche per le card della dashboard
    stats = {
        "frigoriferi": len(frigo_ids),
        "prodotti": n_disponibili,
        "in_scadenza": len(in_scadenza),
        "scaduti": len(scaduti),
    }

    # I 6 prodotti piu' urgenti (prima gli scaduti, poi quelli in scadenza)
    prossime_scadenze = (scaduti + in_scadenza)[:6]

    contesto = {
        "condivisioni": condivisioni,
        "stats": stats,
        "conteggi": conteggi,
        "alert_scadenza": in_scadenza[:5],
        "alert_scaduti": scaduti[:5],
        "prossime_scadenze": prossime_scadenze,
    }
    return render(request, "fridge/home.html", contesto)


@login_required
def frigorifero_create(request):
    if request.method == "POST":
        form = FrigoriferoForm(request.POST)
        if form.is_valid():
            frigo = form.save()
            # Il creatore diventa automaticamente proprietario (owner)
            Condivisione.objects.create(
                utente=request.user,
                frigorifero=frigo,
                ruolo=Condivisione.Ruolo.OWNER,
            )
            messages.success(request, "Frigorifero creato.")
            return redirect("frigorifero_detail", pk=frigo.pk)
    else:
        form = FrigoriferoForm()
    return render(request, "fridge/frigorifero_form.html", {"form": form})


@login_required
def frigorifero_detail(request, pk):
    frigo = _frigo_per_membro(request, pk)
    if frigo is None:
        return HttpResponseForbidden("Non hai accesso a questo frigorifero.")

    elementi = (
        frigo.elementi.select_related("prodotto", "prodotto__categoria")
        .order_by("data_scadenza")
    )
    # Raggruppamento per categoria
    per_categoria = defaultdict(list)
    n_scadenza = n_scaduti = 0
    for item in elementi:
        per_categoria[item.prodotto.categoria.nome].append(item)
        if item.stato == FridgeItem.Stato.CONSUMATO:
            continue
        if item.stato == FridgeItem.Stato.SCADUTO or item.is_scaduto:
            n_scaduti += 1
        elif item.in_scadenza:
            n_scadenza += 1
    gruppi = sorted(per_categoria.items())

    condivisioni = frigo.condivisioni.select_related("utente").all()

    contesto = {
        "frigo": frigo,
        "gruppi": gruppi,
        "totale_elementi": elementi.count(),
        "n_scadenza": n_scadenza,
        "n_scaduti": n_scaduti,
        "condivisioni": condivisioni,
        "is_owner": frigo.is_owner(request.user),
        "item_form": FridgeItemForm(),
        "condivisione_form": CondivisioneForm(frigorifero=frigo),
    }
    return render(request, "fridge/frigorifero_detail.html", contesto)


@login_required
@require_POST
def frigorifero_delete(request, pk):
    frigo = get_object_or_404(Frigorifero, pk=pk)
    if not frigo.is_owner(request.user):
        return HttpResponseForbidden("Solo il proprietario puo' eliminare il frigorifero.")
    frigo.delete()
    messages.success(request, "Frigorifero eliminato.")
    return redirect("home")


# =====================================================================
#  CONDIVISIONE
# =====================================================================
@login_required
@require_POST
def condivisione_add(request, pk):
    frigo = get_object_or_404(Frigorifero, pk=pk)
    if not frigo.is_owner(request.user):
        return HttpResponseForbidden("Solo il proprietario puo' invitare membri.")
    form = CondivisioneForm(request.POST, frigorifero=frigo)
    if form.is_valid():
        Condivisione.objects.create(
            utente=form.utente,
            frigorifero=frigo,
            ruolo=Condivisione.Ruolo.MEMBER,
        )
        messages.success(request, f"Hai condiviso il frigorifero con {form.utente.username}.")
    else:
        for errore in form.errors.get("username", []):
            messages.error(request, errore)
    return redirect("frigorifero_detail", pk=pk)


@login_required
@require_POST
def condivisione_remove(request, pk, cid):
    frigo = get_object_or_404(Frigorifero, pk=pk)
    if not frigo.is_owner(request.user):
        return HttpResponseForbidden("Solo il proprietario puo' rimuovere membri.")
    cond = get_object_or_404(Condivisione, pk=cid, frigorifero=frigo)
    if cond.ruolo == Condivisione.Ruolo.OWNER:
        messages.error(request, "Non puoi rimuovere il proprietario.")
    else:
        cond.delete()
        messages.success(request, "Membro rimosso.")
    return redirect("frigorifero_detail", pk=pk)


# =====================================================================
#  ELEMENTI DEL FRIGORIFERO
# =====================================================================
@login_required
@require_POST
def item_add(request, pk):
    frigo = _frigo_per_membro(request, pk)
    if frigo is None:
        return HttpResponseForbidden("Non hai accesso a questo frigorifero.")
    form = FridgeItemForm(request.POST)
    if form.is_valid():
        item = form.save(commit=False)
        item.frigorifero = frigo
        item.save()
        messages.success(request, "Prodotto aggiunto al frigorifero.")
    else:
        messages.error(request, "Dati non validi: controlla quantita' e scadenza.")
    return redirect("frigorifero_detail", pk=pk)


@login_required
def item_update(request, pk):
    item = get_object_or_404(FridgeItem, pk=pk)
    if item.frigorifero.ruolo_di(request.user) is None:
        return HttpResponseForbidden("Non hai accesso a questo elemento.")
    if request.method == "POST":
        form = FridgeItemUpdateForm(request.POST, instance=item)
        if form.is_valid():
            form.save()
            messages.success(request, "Elemento aggiornato.")
            return redirect("frigorifero_detail", pk=item.frigorifero.pk)
    else:
        form = FridgeItemUpdateForm(instance=item)
    return render(request, "fridge/fridgeitem_form.html", {"form": form, "item": item})


@login_required
@require_POST
def item_delete(request, pk):
    item = get_object_or_404(FridgeItem, pk=pk)
    frigo = item.frigorifero
    if frigo.ruolo_di(request.user) is None:
        return HttpResponseForbidden("Non hai accesso a questo elemento.")
    item.delete()
    messages.success(request, "Elemento rimosso.")
    return redirect("frigorifero_detail", pk=frigo.pk)


# =====================================================================
#  PRODOTTI (catalogo)
# =====================================================================
@login_required
def prodotto_create(request):
    if request.method == "POST":
        form = ProdottoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Prodotto aggiunto al catalogo.")
            return redirect("prodotto_create")
    else:
        form = ProdottoForm()
    prodotti = Prodotto.objects.select_related("categoria").all()
    return render(
        request, "fridge/prodotto_form.html", {"form": form, "prodotti": prodotti}
    )


# =====================================================================
#  RICETTE
# =====================================================================
@login_required
def ricette_list(request):
    ricette = Ricetta.objects.all()
    return render(request, "fridge/ricette_list.html", {"ricette": ricette})


@login_required
def ricetta_detail(request, pk):
    ricetta = get_object_or_404(Ricetta, pk=pk)
    ingredienti = ricetta.lista_ingredienti.select_related("prodotto").all()
    return render(
        request,
        "fridge/ricetta_detail.html",
        {"ricetta": ricetta, "ingredienti": ingredienti},
    )


@login_required
def ricette_suggerite(request, pk):
    """
    Suggerisce le ricette realizzabili con i prodotti disponibili in un
    frigorifero. Per ogni ricetta calcola gli ingredienti mancanti.
    """
    frigo = _frigo_per_membro(request, pk)
    if frigo is None:
        return HttpResponseForbidden("Non hai accesso a questo frigorifero.")

    # Quantita' disponibile per prodotto (solo elementi disponibili)
    disponibilita = {}
    righe = (
        frigo.elementi.filter(stato=FridgeItem.Stato.DISPONIBILE)
        .values("prodotto_id")
        .annotate(totale=Sum("quantita"))
    )
    for r in righe:
        disponibilita[r["prodotto_id"]] = r["totale"]

    realizzabili = []
    quasi_pronte = []
    for ricetta in Ricetta.objects.prefetch_related("lista_ingredienti__prodotto"):
        mancanti = []
        for ing in ricetta.lista_ingredienti.all():
            disp = disponibilita.get(ing.prodotto_id, 0)
            if disp < ing.quantita_necessaria:
                mancanti.append(
                    {"prodotto": ing.prodotto, "manca": ing.quantita_necessaria - disp}
                )
        if not mancanti:
            realizzabili.append(ricetta)
        elif len(mancanti) <= 2:
            quasi_pronte.append({"ricetta": ricetta, "mancanti": mancanti})

    contesto = {
        "frigo": frigo,
        "realizzabili": realizzabili,
        "quasi_pronte": quasi_pronte,
    }
    return render(request, "fridge/ricette_suggerite.html", contesto)


# =====================================================================
#  NOTIFICHE
# =====================================================================
@login_required
def notifiche_list(request):
    notifiche = Notifica.objects.filter(utente=request.user).select_related(
        "fridge_item", "fridge_item__prodotto"
    )
    # Segna come lette quelle visualizzate
    Notifica.objects.filter(utente=request.user, letta=False).update(letta=True)
    return render(request, "fridge/notifiche.html", {"notifiche": notifiche})
