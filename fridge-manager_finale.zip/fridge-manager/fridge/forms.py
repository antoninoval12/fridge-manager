"""Form dell'applicazione Fridge Manager."""

from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.utils import timezone

from .models import Condivisione, FridgeItem, Frigorifero, Prodotto, Ricetta


class RegistrazioneForm(UserCreationForm):
    """Registrazione utente con email obbligatoria e univoca."""

    email = forms.EmailField(required=True, label="Email")

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ("username", "email")

    def clean_email(self):
        email = self.cleaned_data["email"]
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("Questa email e' gia' registrata.")
        return email

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data["email"]
        if commit:
            user.save()
        return user


class FrigoriferoForm(forms.ModelForm):
    class Meta:
        model = Frigorifero
        fields = ["nome"]
        widgets = {
            "nome": forms.TextInput(attrs={"placeholder": "Es. Frigo di casa"}),
        }


class CondivisioneForm(forms.Form):
    """Aggiunge un membro a un frigorifero a partire dallo username."""

    username = forms.CharField(label="Username dell'utente da invitare", max_length=150)

    def __init__(self, *args, frigorifero=None, **kwargs):
        self.frigorifero = frigorifero
        super().__init__(*args, **kwargs)

    def clean_username(self):
        username = self.cleaned_data["username"].strip()
        try:
            utente = User.objects.get(username=username)
        except User.DoesNotExist:
            raise forms.ValidationError("Nessun utente con questo username.")
        if self.frigorifero and Condivisione.objects.filter(
            frigorifero=self.frigorifero, utente=utente
        ).exists():
            raise forms.ValidationError("L'utente ha gia' accesso a questo frigorifero.")
        self.utente = utente
        return username


class FridgeItemForm(forms.ModelForm):
    class Meta:
        model = FridgeItem
        fields = ["prodotto", "quantita", "data_scadenza"]
        widgets = {
            "prodotto": forms.Select(attrs={"class": "form-select"}),
            "quantita": forms.NumberInput(attrs={"class": "form-control", "min": 1}),
            "data_scadenza": forms.DateInput(
                attrs={"type": "date", "class": "form-control"}, format="%Y-%m-%d"
            ),
        }

    def clean_data_scadenza(self):
        data = self.cleaned_data["data_scadenza"]
        if data < timezone.localdate():
            raise forms.ValidationError(
                "La data di scadenza deve essere successiva a oggi."
            )
        return data


class FridgeItemUpdateForm(forms.ModelForm):
    """Aggiornamento di quantita' e stato di un elemento gia' presente."""

    class Meta:
        model = FridgeItem
        fields = ["quantita", "stato"]
        widgets = {
            "quantita": forms.NumberInput(attrs={"class": "form-control", "min": 1}),
            "stato": forms.Select(attrs={"class": "form-select"}),
        }


class ProdottoForm(forms.ModelForm):
    class Meta:
        model = Prodotto
        fields = ["nome", "categoria"]
        widgets = {
            "nome": forms.TextInput(attrs={"class": "form-control"}),
            "categoria": forms.Select(attrs={"class": "form-select"}),
        }
