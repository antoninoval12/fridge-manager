"""Filtri di template personalizzati per Fridge Manager."""

from django import template

register = template.Library()


@register.filter
def get_item(dizionario, chiave):
    """Permette di accedere a dict[key] nei template: {{ mydict|get_item:key }}."""
    if dizionario is None:
        return 0
    return dizionario.get(chiave, 0)
