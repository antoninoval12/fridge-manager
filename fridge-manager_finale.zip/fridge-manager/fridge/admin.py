from django.contrib import admin

from .models import (
    Categoria,
    Condivisione,
    FridgeItem,
    Frigorifero,
    IngredienteRicetta,
    Notifica,
    Prodotto,
    Ricetta,
)


class CondivisioneInline(admin.TabularInline):
    model = Condivisione
    extra = 1


class FridgeItemInline(admin.TabularInline):
    model = FridgeItem
    extra = 0


@admin.register(Frigorifero)
class FrigoriferoAdmin(admin.ModelAdmin):
    list_display = ("nome", "proprietario", "data_creazione")
    inlines = [CondivisioneInline, FridgeItemInline]


@admin.register(Prodotto)
class ProdottoAdmin(admin.ModelAdmin):
    list_display = ("nome", "categoria")
    list_filter = ("categoria",)
    search_fields = ("nome",)


@admin.register(FridgeItem)
class FridgeItemAdmin(admin.ModelAdmin):
    list_display = ("prodotto", "frigorifero", "quantita", "data_scadenza", "stato")
    list_filter = ("stato", "frigorifero")


class IngredienteInline(admin.TabularInline):
    model = IngredienteRicetta
    extra = 1


@admin.register(Ricetta)
class RicettaAdmin(admin.ModelAdmin):
    list_display = ("nome",)
    inlines = [IngredienteInline]


@admin.register(Notifica)
class NotificaAdmin(admin.ModelAdmin):
    list_display = ("utente", "messaggio", "data_creazione", "letta")
    list_filter = ("letta",)


admin.site.register(Categoria)
admin.site.register(Condivisione)
