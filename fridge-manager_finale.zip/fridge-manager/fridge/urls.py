from django.urls import path

from . import views

urlpatterns = [
    # Autenticazione
    path("accounts/login/", views.login_view, name="login"),
    path("accounts/logout/", views.logout_view, name="logout"),
    path("accounts/register/", views.register_view, name="register"),
    # Home
    path("", views.home, name="home"),
    # Frigoriferi
    path("frigoriferi/nuovo/", views.frigorifero_create, name="frigorifero_create"),
    path("frigoriferi/<int:pk>/", views.frigorifero_detail, name="frigorifero_detail"),
    path("frigoriferi/<int:pk>/elimina/", views.frigorifero_delete, name="frigorifero_delete"),
    # Condivisione
    path("frigoriferi/<int:pk>/condividi/", views.condivisione_add, name="condivisione_add"),
    path(
        "frigoriferi/<int:pk>/condivisioni/<int:cid>/rimuovi/",
        views.condivisione_remove,
        name="condivisione_remove",
    ),
    # Elementi
    path("frigoriferi/<int:pk>/aggiungi/", views.item_add, name="item_add"),
    path("elementi/<int:pk>/modifica/", views.item_update, name="item_update"),
    path("elementi/<int:pk>/elimina/", views.item_delete, name="item_delete"),
    # Catalogo prodotti
    path("prodotti/nuovo/", views.prodotto_create, name="prodotto_create"),
    # Ricette
    path("ricette/", views.ricette_list, name="ricette_list"),
    path("ricette/<int:pk>/", views.ricetta_detail, name="ricetta_detail"),
    path(
        "frigoriferi/<int:pk>/ricette-suggerite/",
        views.ricette_suggerite,
        name="ricette_suggerite",
    ),
    # Notifiche
    path("notifiche/", views.notifiche_list, name="notifiche_list"),
]
